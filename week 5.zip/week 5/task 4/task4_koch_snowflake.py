# koch_snowflake.py
# Modified from sierpinski_triangle.py to draw a Koch snowflake instead.
import math
from tkinter import *

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        # Starting equilateral triangle (points A, B, C going clockwise)
        size = 300
        cx, cy = self.width / 2, self.height / 2 + 30
        # Triangle vertices
        p1 = [cx, cy - size / math.sqrt(3)]
        p2 = [cx + size / 2, cy + size / (2 * math.sqrt(3))]
        p3 = [cx - size / 2, cy + size / (2 * math.sqrt(3))]

        order = int(self.order.get())
        self.kochLine(order, p1, p2)
        self.kochLine(order, p2, p3)
        self.kochLine(order, p3, p1)

    def kochLine(self, order, p1, p2):
        if order == 0:  # Base case: draw a straight line
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            # Divide the line into three equal segments
            dx = (p2[0] - p1[0]) / 3
            dy = (p2[1] - p1[1]) / 3
            a = [p1[0] + dx, p1[1] + dy]
            b = [p1[0] + 2 * dx, p1[1] + 2 * dy]

            # Compute the peak of the outward equilateral bump
            # Rotate vector (b - a) by -60 degrees around point a
            angle = -math.pi / 3  # -60 degrees (outward)
            vx = b[0] - a[0]
            vy = b[1] - a[1]
            peak = [
                a[0] + vx * math.cos(angle) - vy * math.sin(angle),
                a[1] + vx * math.sin(angle) + vy * math.cos(angle)
            ]

            # Recursively draw the four segments
            self.kochLine(order - 1, p1, a)
            self.kochLine(order - 1, a, peak)
            self.kochLine(order - 1, peak, b)
            self.kochLine(order - 1, b, p2)

KochSnowflake()