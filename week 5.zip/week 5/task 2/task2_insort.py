import random
import timeit

# Insertion sort (from recursion_mergesort.py,)
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr


# Test insertion sort across data sizes (same sizes as merge sort)
print("--- Insertion Sort across data sizes ---")
print(f"{'Size':<10}{'Insertion Sort (s)':<20}")
for n in [100, 500, 1000, 5000, 10000]:
    data = [random.randint(1, 1000) for _ in range(n)]
    t = timeit.timeit(lambda: insertion_sort(data.copy()), number=1)
    print(f"{n:<10}{t:<20.6f}")