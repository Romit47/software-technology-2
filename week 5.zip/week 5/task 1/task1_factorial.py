import timeit
import sys
sys.setrecursionlimit(20000)

# Recursive version (from recursion_mergesort.py,)
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Iterative version
def factorial_iter(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

# Correctness check
print(f"fact(5): recursive={factorial(5)}, iterative={factorial_iter(5)}")

# Benchmark across data sizes
print("\n--- Factorial: recursive vs iterative ---")
print(f"{'n':<8}{'Recursive (s)':<18}{'Iterative (s)':<18}")
for n in [100, 500, 1000, 2000]:
    r = timeit.timeit(lambda: factorial(n), number=100)
    i = timeit.timeit(lambda: factorial_iter(n), number=100)
    print(f"{n:<8}{r:<18.6f}{i:<18.6f}")