import timeit

# Recursive version (from recursion_mergesort.py,)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Iterative version
def fibonacci_iter(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

# Correctness check
print(f"fib(10): recursive={fibonacci(10)}, iterative={fibonacci_iter(10)}")

# Benchmark across data sizes
print("\n--- Fibonacci: recursive vs iterative ---")
print(f"{'n':<8}{'Recursive (s)':<18}{'Iterative (s)':<18}")
for n in [10, 20, 25, 30]:
    r = timeit.timeit(lambda: fibonacci(n), number=10)
    i = timeit.timeit(lambda: fibonacci_iter(n), number=10)
    print(f"{n:<8}{r:<18.6f}{i:<18.6f}")