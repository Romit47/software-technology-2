import timeit
import sys
sys.setrecursionlimit(20000)

# Recursive version (from recursion_mergesort.py,)
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Iterative version
def sum_of_natural_numbers_iter(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

# Correctness check
print(f"sum(5): recursive={sum_of_natural_numbers(5)}, iterative={sum_of_natural_numbers_iter(5)}")

# Benchmark across data sizes
print("\n--- Sum of natural numbers: recursive vs iterative ---")
print(f"{'n':<8}{'Recursive (s)':<18}{'Iterative (s)':<18}")
for n in [100, 500, 1000, 2000]:
    r = timeit.timeit(lambda: sum_of_natural_numbers(n), number=100)
    i = timeit.timeit(lambda: sum_of_natural_numbers_iter(n), number=100)
    print(f"{n:<8}{r:<18.6f}{i:<18.6f}")