

# TowerOfHanoi_count.py
# Modified version that counts the number of moves using a global variable.
 
move_count = 0  # Global variable to count moves
 
def main():
    global move_count
    n = eval(input("Enter number of disks: "))
    move_count = 0  # Reset counter at start
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"\nThe total number of moves is {move_count}")
 
def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    if n == 1:  # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)
 
main()