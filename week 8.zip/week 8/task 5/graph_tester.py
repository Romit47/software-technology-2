from graph import Graph

# ===== Undirected graph =====
print("=== Undirected Graph ===")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A-B, B-C, C-D:")
g.print_graph()

g.remove_edge('B', 'C')
print("\nAfter removing edge B-C:")
g.print_graph()

g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()

# ===== Directed graph =====
print("\n=== Directed Graph ===")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A->B, B->C, C->D:")
g.print_graph()

g.remove_edge('B', 'C')
print("\nAfter removing edge B->C:")
g.print_graph()

g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()

# ===== BFS and DFS Test =====
print("\n=== BFS and DFS Test ===")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'D')
g.add_edge('D', 'E')

print("Graph structure:")
g.print_graph()

print("\nBFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

print("\nDFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# ===== Cycle Detection in Undirected Graphs =====
print("\n=== Cycle Detection (Undirected) ===")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')
print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# ===== Cycle Detection in Directed Graphs =====
print("\n=== Cycle Detection (Directed) ===")

directed_cycle = Graph(directed=True)
for v in ['A', 'B', 'C']:
    directed_cycle.add_vertex(v)
directed_cycle.add_edge('A', 'B')
directed_cycle.add_edge('B', 'C')
directed_cycle.add_edge('C', 'A')
print("Does directed_cycle have a cycle? ", directed_cycle.has_directed_cycle())

directed_acyclic = Graph(directed=True)
for v in ['X', 'Y', 'Z']:
    directed_acyclic.add_vertex(v)
directed_acyclic.add_edge('X', 'Y')
directed_acyclic.add_edge('Y', 'Z')
directed_acyclic.add_edge('X', 'Z')
print("Does directed_acyclic have a cycle? ", directed_acyclic.has_directed_cycle())

# ===== Weighted Directed Graph =====
print("\n=== Weighted Directed Graph ===")
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()