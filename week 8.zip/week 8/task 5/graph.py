class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}      # adjacency list: {vertex: [neighbors]}
        self.weights = {}    # edge weights: {(v1, v2): weight}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]
            if not self.directed and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print(f"Edge {vertex1}-{vertex2} not found.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            for other in list(self.graph.keys()):
                if vertex in self.graph[other]:
                    self.graph[other].remove(vertex)
                if self.weighted:
                    self.weights.pop((other, vertex), None)
                    self.weights.pop((vertex, other), None)
            del self.graph[vertex]
        else:
            print(f"Vertex {vertex} not found.")

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                neighbors = [f"{n}({self.weights.get((vertex, n), 0)})"
                             for n in self.graph[vertex]]
                print(f"{vertex} -> {', '.join(neighbors)}")
            else:
                print(f"{vertex} -> {', '.join(self.graph[vertex])}")

    def bfs(self, start):
        if start not in self.graph:
            print(f"Vertex {start} not found.")
            return []

        visited = []
        seen = set()
        queue = [start]
        seen.add(start)

        while queue:
            current = queue.pop(0)
            visited.append(current)
            for neighbor in self.graph[current]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    queue.append(neighbor)
        return visited

    def dfs(self, start):
        if start not in self.graph:
            print(f"Vertex {start} not found.")
            return []

        visited = []
        seen = set()
        stack = [start]

        while stack:
            current = stack.pop()
            if current not in seen:
                seen.add(current)
                visited.append(current)
                for neighbor in reversed(self.graph[current]):
                    if neighbor not in seen:
                        stack.append(neighbor)
        return visited

    def has_undirected_cycle(self):
        seen = set()

        def dfs_check(current, parent):
            seen.add(current)
            for neighbor in self.graph[current]:
                if neighbor not in seen:
                    if dfs_check(neighbor, current):
                        return True
                elif neighbor != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in seen:
                if dfs_check(vertex, None):
                    return True
        return False

    def has_directed_cycle(self):
        seen = set()
        rec_stack = set()

        def dfs_check(current):
            seen.add(current)
            rec_stack.add(current)
            for neighbor in self.graph[current]:
                if neighbor not in seen:
                    if dfs_check(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            rec_stack.remove(current)
            return False

        for vertex in self.graph:
            if vertex not in seen:
                if dfs_check(vertex):
                    return True
        return False