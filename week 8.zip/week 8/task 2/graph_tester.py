from graph import Graph

# ===== Undirected graph =====
print("=== Undirected Graph ===")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A-B, B-C, C-D:")
g.print_graph()

g.remove_edge('B', 'C')
print("\nAfter removing edge B-C:")
g.print_graph()

g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()

# ===== Directed graph =====
print("\n=== Directed Graph ===")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
print("After adding vertices A, B, C, D:")
g.print_graph()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("\nAfter adding edges A->B, B->C, C->D:")
g.print_graph()

g.remove_edge('B', 'C')
print("\nAfter removing edge B->C:")
g.print_graph()

g.remove_vertex('D')
print("\nAfter removing vertex D:")
g.print_graph()

# ===== BFS Test =====
print("\n=== BFS Test ===")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'D')
g.add_edge('D', 'E')

print("Graph structure:")
g.print_graph()

# BFS on the graph from Activity 1
print("\nBFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)