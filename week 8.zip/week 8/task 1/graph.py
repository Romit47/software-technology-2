class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}      # adjacency list: {vertex: [neighbors]}
        self.weights = {}    # edge weights: {(v1, v2): weight}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted and (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]
            # If undirected, also remove the reverse edge
            if not self.directed and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted and (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]
        else:
            print(f"Edge {vertex1}-{vertex2} not found.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove this vertex from every other vertex's neighbor list
            for other in list(self.graph.keys()):
                if vertex in self.graph[other]:
                    self.graph[other].remove(vertex)
                # Clean up any weights involving this vertex
                if self.weighted:
                    self.weights.pop((other, vertex), None)
                    self.weights.pop((vertex, other), None)
            # Finally, delete the vertex itself
            del self.graph[vertex]
        else:
            print(f"Vertex {vertex} not found.")

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                neighbors = [f"{n}({self.weights.get((vertex, n), 0)})"
                             for n in self.graph[vertex]]
                print(f"{vertex} -> {', '.join(neighbors)}")
            else:
                print(f"{vertex} -> {', '.join(self.graph[vertex])}")