# task5_red_black_tree.py
# Red-Black Tree implementation + benchmark vs BST and AVL.
import time, random, sys
sys.setrecursionlimit(20000)

# ---------- Simple BST ----------
class BSTNode:
    def __init__(self, v): self.v=v; self.l=None; self.r=None
def bst_insert(root, v):
    if root is None: return BSTNode(v)
    if v < root.v: root.l = bst_insert(root.l, v)
    else: root.r = bst_insert(root.r, v)
    return root
def bst_search(root, v):
    while root:
        if v == root.v: return root
        root = root.l if v < root.v else root.r
    return None

# ---------- AVL Tree ----------
class AVLNode:
    def __init__(self, v): self.v=v; self.l=None; self.r=None; self.h=1
def avl_h(n): return n.h if n else 0
def avl_bf(n): return avl_h(n.l) - avl_h(n.r)
def avl_rr(y):
    x = y.l; T = x.r
    x.r = y; y.l = T
    y.h = 1 + max(avl_h(y.l), avl_h(y.r))
    x.h = 1 + max(avl_h(x.l), avl_h(x.r))
    return x
def avl_lr(x):
    y = x.r; T = y.l
    y.l = x; x.r = T
    x.h = 1 + max(avl_h(x.l), avl_h(x.r))
    y.h = 1 + max(avl_h(y.l), avl_h(y.r))
    return y
def avl_insert(root, v):
    if root is None: return AVLNode(v)
    if v < root.v: root.l = avl_insert(root.l, v)
    else: root.r = avl_insert(root.r, v)
    root.h = 1 + max(avl_h(root.l), avl_h(root.r))
    b = avl_bf(root)
    if b > 1 and v < root.l.v: return avl_rr(root)
    if b < -1 and v > root.r.v: return avl_lr(root)
    if b > 1 and v > root.l.v:
        root.l = avl_lr(root.l); return avl_rr(root)
    if b < -1 and v < root.r.v:
        root.r = avl_rr(root.r); return avl_lr(root)
    return root
def avl_search(root, v):
    while root:
        if v == root.v: return root
        root = root.l if v < root.v else root.r
    return None

# ---------- Red-Black Tree ----------
RED, BLACK = 'R', 'B'
class RBNode:
    def __init__(self, v, color=RED):
        self.v = v; self.color = color
        self.l = None; self.r = None; self.p = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, BLACK)
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.r
        x.r = y.l
        if y.l != self.NIL: y.l.p = x
        y.p = x.p
        if x.p is None: self.root = y
        elif x == x.p.l: x.p.l = y
        else: x.p.r = y
        y.l = x; x.p = y

    def right_rotate(self, x):
        y = x.l
        x.l = y.r
        if y.r != self.NIL: y.r.p = x
        y.p = x.p
        if x.p is None: self.root = y
        elif x == x.p.r: x.p.r = y
        else: x.p.l = y
        y.r = x; x.p = y

    def insert(self, v):
        n = RBNode(v, RED)
        n.l = self.NIL; n.r = self.NIL
        parent = None; cur = self.root
        while cur != self.NIL:
            parent = cur
            cur = cur.l if v < cur.v else cur.r
        n.p = parent
        if parent is None: self.root = n
        elif v < parent.v: parent.l = n
        else: parent.r = n
        self._fix_insert(n)

    def _fix_insert(self, n):
        while n.p and n.p.color == RED:
            gp = n.p.p
            if gp is None: break
            if n.p == gp.l:
                u = gp.r
                if u.color == RED:
                    n.p.color = BLACK; u.color = BLACK; gp.color = RED; n = gp
                else:
                    if n == n.p.r:
                        n = n.p; self.left_rotate(n)
                    n.p.color = BLACK; gp.color = RED
                    self.right_rotate(gp)
            else:
                u = gp.l
                if u.color == RED:
                    n.p.color = BLACK; u.color = BLACK; gp.color = RED; n = gp
                else:
                    if n == n.p.l:
                        n = n.p; self.right_rotate(n)
                    n.p.color = BLACK; gp.color = RED
                    self.left_rotate(gp)
        self.root.color = BLACK

    def search(self, v):
        cur = self.root
        while cur != self.NIL:
            if v == cur.v: return cur
            cur = cur.l if v < cur.v else cur.r
        return None


# ---------- Benchmark ----------
def benchmark(size):
    data = [random.randint(1, size * 10) for _ in range(size)]
    queries = random.sample(data, min(1000, size))

    # BST
    t0 = time.perf_counter()
    bst_root = None
    for v in data: bst_root = bst_insert(bst_root, v)
    bst_ins = time.perf_counter() - t0
    t0 = time.perf_counter()
    for q in queries: bst_search(bst_root, q)
    bst_srch = time.perf_counter() - t0

    # AVL
    t0 = time.perf_counter()
    avl_root = None
    for v in data: avl_root = avl_insert(avl_root, v)
    avl_ins = time.perf_counter() - t0
    t0 = time.perf_counter()
    for q in queries: avl_search(avl_root, q)
    avl_srch = time.perf_counter() - t0

    # Red-Black
    t0 = time.perf_counter()
    rbt = RedBlackTree()
    for v in data: rbt.insert(v)
    rb_ins = time.perf_counter() - t0
    t0 = time.perf_counter()
    for q in queries: rbt.search(q)
    rb_srch = time.perf_counter() - t0

    return bst_ins, avl_ins, rb_ins, bst_srch, avl_srch, rb_srch


if __name__ == "__main__":
    # Quick correctness demo of Red-Black tree
    print("--- Red-Black Tree demo ---")
    rbt = RedBlackTree()
    for v in [10, 20, 30, 15, 25, 5, 1]:
        rbt.insert(v)
    print(f"Root value: {rbt.root.v}, color: {rbt.root.color}")
    for q in [15, 25, 100]:
        r = rbt.search(q)
        print(f"Search {q}: {'found' if r else 'not found'}")

    print("\n--- Benchmark: BST vs AVL vs Red-Black (random data) ---")
    header = f"{'Size':<8}{'BST ins':<12}{'AVL ins':<12}{'RB ins':<12}{'BST srch':<12}{'AVL srch':<12}{'RB srch':<12}"
    print(header)
    for n in [1000, 2000, 5000, 10000]:
        b = benchmark(n)
        print(f"{n:<8}" + "".join(f"{x:<12.6f}" for x in b))

    # ---------- Visualization ----------
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n(matplotlib not installed — skipping visualization)")
        sys.exit(0)

    # Build a small RB tree to visualize
    vis_tree = RedBlackTree()
    for v in [10, 20, 30, 15, 25, 5, 1, 8, 35, 40]:
        vis_tree.insert(v)

    # Assign (x, y) positions via inorder traversal
    positions = {}
    def assign_pos(node, depth, counter):
        if node == vis_tree.NIL or node is None:
            return
        assign_pos(node.l, depth + 1, counter)
        positions[id(node)] = (counter[0], -depth)
        counter[0] += 1
        assign_pos(node.r, depth + 1, counter)
    assign_pos(vis_tree.root, 0, [0])

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_title("Red-Black Tree Visualization")
    ax.axis('off')

    # Draw edges first
    def draw_edges(node):
        if node == vis_tree.NIL or node is None:
            return
        x1, y1 = positions[id(node)]
        for child in (node.l, node.r):
            if child != vis_tree.NIL and child is not None:
                x2, y2 = positions[id(child)]
                ax.plot([x1, x2], [y1, y2], 'k-', zorder=1)
                draw_edges(child)
    draw_edges(vis_tree.root)

    # Draw nodes on top
    def draw_nodes(node):
        if node == vis_tree.NIL or node is None:
            return
        x, y = positions[id(node)]
        color = 'red' if node.color == RED else 'black'
        text_color = 'white' if node.color == BLACK else 'white'
        ax.scatter(x, y, s=900, c=color, edgecolors='black', zorder=2)
        ax.text(x, y, str(node.v), ha='center', va='center',
                color=text_color, fontsize=10, fontweight='bold', zorder=3)
        draw_nodes(node.l); draw_nodes(node.r)
    draw_nodes(vis_tree.root)

    plt.tight_layout()
    plt.savefig('red_black_tree_visualization.png', dpi=100)
    print("\nVisualization saved as 'red_black_tree_visualization.png'")
    plt.show()