package com.example.final_assignment;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.util.List;

public class MLKitActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 3000;
    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewOutput;
    private Button buttonEditResult;
    private String readerType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mlkit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Link variables to UI elements
        imageView = findViewById(R.id.imageViewMLKit);
        textViewOutput = findViewById(R.id.textViewOutput);
        buttonEditResult = findViewById(R.id.buttonEditResult);

        // Get reader type from Activity 1 (MainActivity)
        readerType = getIntent().getStringExtra("readerType");

        // Show reader type as title
        TextView textViewReaderType = findViewById(R.id.textViewReaderType);
        textViewReaderType.setText(readerType);

        // Show the same image as Activity 1 based on reader type
        if (readerType.equals("Barcode Reader")) {
            imageView.setImageResource(R.drawable.barcode);
        } else if (readerType.equals("Content Reader")) {
            imageView.setImageResource(R.drawable.content);
        } else if (readerType.equals("Text Reader")) {
            imageView.setImageResource(R.drawable.text);
        }

        // Open Camera button - opens Activity 3 (built-in camera)
        Button buttonOpenCamera = findViewById(R.id.buttonOpenCamera);
        buttonOpenCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCamera();
            }
        });

        // Load Image button - opens Activity 4 (built-in gallery)
        Button buttonLoadImage = findViewById(R.id.buttonLoadImage);
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadImage();
            }
        });

        // Edit Result button - opens Activity 5 (EditActivity)
        buttonEditResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MLKitActivity.this, EditActivity.class);
                intent.putExtra("readerType", readerType);
                intent.putExtra("result", textViewOutput.getText().toString());
                intent.putExtra("imageUri", imageFileUri.toString());
                startActivity(intent);
            }
        });
    }

    // Check camera permission
    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission) ==
                PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }

    // Open built-in camera (Activity 3)
    public void openCamera() {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    // Open built-in gallery (Activity 4)
    public void loadImage() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    // Handle result from camera or gallery
    ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == RESULT_OK) {
                                if (result.getData() != null &&
                                        result.getData().getData() != null) {
                                    imageFileUri = result.getData().getData();
                                }
                                imageView.setImageURI(imageFileUri);
                                textViewOutput.setText("");
                                buttonEditResult.setVisibility(View.GONE);

                                // Send image to ML Kit based on reader type
                                InputImage image = null;
                                try {
                                    image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (image != null) {
                                    if (readerType.equals("Barcode Reader")) {
                                        processImageFromBarcodeReader(image);
                                    } else if (readerType.equals("Content Reader")) {
                                        processImageFromContentReader(image);
                                    } else if (readerType.equals("Text Reader")) {
                                        processImageFromTextReader(image);
                                    }
                                }
                            }
                        }
                    });

    // Barcode Reader using ML Kit
    public void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<Barcode>>() {
                    @Override
                    public void onSuccess(List<Barcode> barcodes) {
                        textViewOutput.append(Html.fromHtml(
                                "<b>Detected barcode:</b><br>", Html.FROM_HTML_MODE_LEGACY));
                        String result = "";
                        for (Barcode barcode : barcodes) {
                            result = barcode.getRawValue();
                            textViewOutput.append(result + "\n");
                        }
                        if (result.length() < 2) {
                            textViewOutput.append("Barcode not found.\n");
                        }
                        buttonEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed to process image.");
                    }
                });
    }

    // Content Reader using ML Kit Image Labeling
    public void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<ImageLabel>>() {
                    @Override
                    public void onSuccess(List<ImageLabel> labels) {
                        textViewOutput.append(Html.fromHtml(
                                "<b>Recognised image content:</b><br>", Html.FROM_HTML_MODE_LEGACY));
                        int count = 1;
                        for (ImageLabel label : labels) {
                            String text = count + ". " + label.getText() +
                                    " (" + Math.round(label.getConfidence() * 100) + "% confidence)\n";
                            textViewOutput.append(text);
                            count++;
                            if (count > 3) break; // show top 3 labels
                        }
                        buttonEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed to process image.");
                    }
                });
    }

    // Text Reader using ML Kit Text Recognition
    public void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(new OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text visionText) {
                        textViewOutput.append(Html.fromHtml(
                                "<b>Extracted text:</b><br>", Html.FROM_HTML_MODE_LEGACY));
                        String result = visionText.getText();
                        if (result.isEmpty()) {
                            textViewOutput.append("No text found.\n");
                        } else {
                            textViewOutput.append(result + "\n");
                        }
                        buttonEditResult.setVisibility(View.VISIBLE);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed to process image.");
                    }
                });
    }
}