package com.example.final_assignment;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ItemDetailActivity extends AppCompatActivity {

    private String filename;
    private String reader;
    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get data from Activity 6 (ListViewActivity)
        filename = getIntent().getStringExtra("filename");
        reader = getIntent().getStringExtra("reader");
        text = getIntent().getStringExtra("text");

        // Show reader type and result text
        TextView textViewReaderType = findViewById(R.id.textViewReaderType);
        textViewReaderType.setText(reader);

        TextView textViewResult = findViewById(R.id.textViewResult);
        textViewResult.setText(text);

        // Show image from gallery using filename
        ImageView imageViewDetail = findViewById(R.id.imageViewDetail);
        Uri imageUri = getImageUri(filename);
        if (imageUri != null) {
            imageViewDetail.setImageURI(imageUri);
        }

        // Edit button - opens Activity 5 (EditActivity) with current data
        Button buttonEdit = findViewById(R.id.buttonEdit);
        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = getImageUri(filename);
                Intent intent = new Intent(ItemDetailActivity.this, EditActivity.class);
                intent.putExtra("readerType", reader);
                intent.putExtra("result", text);
                intent.putExtra("imageUri", uri.toString());
                startActivity(intent);
            }
        });

        // Delete button - deletes from Firebase and goes back to Activity 6
        Button buttonDelete = findViewById(R.id.buttonDelete);
        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Find and delete the matching item from Firebase
                DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage");
                dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot child : snapshot.getChildren()) {
                            FirebaseItem item = child.getValue(FirebaseItem.class);
                            if (item != null && item.getFilename().equals(filename)) {
                                child.getRef().removeValue();
                                break;
                            }
                        }
                        // Go back to Activity 6 (ListViewActivity) with updated list
                        Intent intent = new Intent(ItemDetailActivity.this, ListViewActivity.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                    }
                });
            }
        });

        // Cancel button - goes back to Activity 6 with no changes
        Button buttonCancel = findViewById(R.id.buttonCancel);
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ItemDetailActivity.this, ListViewActivity.class);
                startActivity(intent);
            }
        });
    }

    // Get image URI from gallery by filename
    private Uri getImageUri(String filename) {
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME};
        String selection = MediaStore.Images.Media.DISPLAY_NAME + "=?";
        String[] selectionArgs = {filename + ".png"};
        try (Cursor cursor = getContentResolver().query(uri, projection, selection, selectionArgs, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                long imageId = cursor.getLong(idColumn);
                return ContentUris.withAppendedId(uri, imageId);
            }
        }
        return null;
    }
}