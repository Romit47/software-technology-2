package com.example.final_assignment;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDateTime;

public class EditActivity extends AppCompatActivity {

    private ImageView imageViewEdit;
    private EditText editTextResult;
    private TextView textViewReaderType;
    private String readerType;
    private String imageUriString;
    private Uri imageFileUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Link variables to UI elements
        imageViewEdit = findViewById(R.id.imageViewEdit);
        editTextResult = findViewById(R.id.editTextResult);
        textViewReaderType = findViewById(R.id.textViewReaderType);

        // Get data from Activity 2 (MLKitActivity)
        readerType = getIntent().getStringExtra("readerType");
        String result = getIntent().getStringExtra("result");
        imageUriString = getIntent().getStringExtra("imageUri");
        imageFileUri = Uri.parse(imageUriString);

        // Show reader type and result
        textViewReaderType.setText(readerType);
        editTextResult.setText(result);

        // Show the image (unchanged)
        imageViewEdit.setImageURI(imageFileUri);

        // Save button - saves to Firebase and opens Activity 6
        Button buttonSave = findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Create unique filename from current date and time
                String currentDateTime = LocalDateTime.now().toString();
                String filename = currentDateTime.replaceAll("\\D+", "");

                // Save image to gallery with that filename
                Bitmap bitmap = getBitmapFromUri(imageFileUri);
                saveImageToGallery(bitmap, filename, EditActivity.this);

                // Get the edited text
                String updatedResult = editTextResult.getText().toString();

                // Save to Firebase Realtime Database
                DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Storage");
                String key = dbRef.push().getKey();
                DatabaseReference itemRef = dbRef.child(key);
                itemRef.child("filename").setValue(filename);
                itemRef.child("reader").setValue(readerType);
                itemRef.child("text").setValue(updatedResult);

                // Open Activity 6 (ListViewActivity) after saving
                Intent intent = new Intent(EditActivity.this, ListViewActivity.class);
                startActivity(intent);
            }
        });
    }

    // Convert URI to Bitmap
    private Bitmap getBitmapFromUri(Uri uri) {
        try {
            ImageDecoder.Source source =
                    ImageDecoder.createSource(getContentResolver(), uri);
            return ImageDecoder.decodeBitmap(source);
        } catch (IOException e) {
            Log.e("EditActivity", "Failed to load image", e);
            return null;
        }
    }

    // Save image to gallery with given filename
    private void saveImageToGallery(Bitmap bitmap, String fileName, Context context) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);
        Uri imageUri = context.getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        try {
            OutputStream outputStream =
                    context.getContentResolver().openOutputStream(imageUri);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            Log.d("EditActivity", "Image saved: " + imageUri.toString());
        } catch (IOException e) {
            Log.e("EditActivity", "Error saving image", e);
        }
    }
}